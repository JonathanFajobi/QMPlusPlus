let context = new AudioContext() 

var start = document.getElementById('start')
var end = document.getElementById('end')

context.audioWorklet.addModule('worklet.js').then(() => {
    let noiseExample = new AudioWorkletNode(context,'noise-example')
    let gainExample = new AudioWorkletNode(context,'gain-example')
    //connect weighted average filter here
    noiseExample.connect(gainExample)
    gainExample.connect(context.destination)
    //stops sound from automatically outputting
    gainExample.disconnect()
})

//buttons that can be used to stop and start sound, recordings, filters etc
//figure out how to implement these
start.addEventListener('click', () => startSound())
end.addEventListener('click', () => endSound())


startSound = () => {
    //resumes context
    if (context.state === 'suspended'){
        context.resume()
    }
}

endSound = () => {
    //when editing this line, keep the signal chain in mind, i.e the last node that connects
    //to the output should not be connected
    gainExample.disconnect()
}


rangeLabel.innerHTML = range.value

range.oninput = () => {
    rangeLabel.innerHTML = range.value
}
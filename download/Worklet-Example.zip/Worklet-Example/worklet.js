registerProcessor('noise-example', class extends AudioWorkletProcessor {
    process(input, output)
    {
        for (let i=0; i< output[0][0].length; ++i){
            output[0][0][i] = 2 * Math.random() - 1
        }
        return true
    }
})

registerProcessor('gain-example',class extends AudioWorkletProcessor {
    static get parameterDescriptors() 
    { 
        return [{name:'gain',defaultValue:0.5}] 
    }

    process(inputs, outputs, params) 
    {
      const input = inputs[0]
      const output = outputs[0]
      for (let channel=0;channel<inputs[0].length;++channel) 
      {
        for (let i=0;i<input[channel].length;++i) 
        {
            output[channel][i] = input[channel][i] * params.gain[0]
        }
        
      }
        
      return true
    }
  })

//There are a few errors and redundant lines here, remove these to make it work correctly
//In this example, c is the coefficient, if anything else is not clear, watch the video from 13:30 onwards
//hint: (1-coefficient)*this.lastOutput is the previous output, the inpChannel holds the most recent output
  let n = 0;
  registerProcessor('wa-filter', class extends AudioWorkletProcessor {
    static get parameterDescriptors() 
    { 
        return [{name:'c', defaultValue:10, minValue:0}, {name:'frequency',defaultValue:1000,minValue:0}]
    }
    constructor() 
    {
      super()
      this.lastOutput = 0
    }
  
    process(inputs, outputs, params)
    {
      let coefficient
      let input = inputs[n]
      let lastInput = inputs[n]
      let output = outputs[n]
      let frequency = params.frequency
  
      for (let channel = 0; channel < output.length; ++channel){
  
        let inpChannel = input[channel]
        let inpChannel2 = lastInput[channel]
        let outputChannel = output[channel]
        //hint: double check if certain lines are required
        coefficient = 2 * Math.PI * params.c[0]/ sampleRate
  //Here is where the affect is generated. In order to make a simple wa filter work you must use the formula
  //CurrentInp = CurrentInp & Coeff + LastInp & LastLastCoeff + LastInp & LastLastCoeff
        for (let i = 0; i < outputChannel.length; ++i) {
          outputChannel[i] = (inpChannel[i]+ inpChannel2[i])/2 * coefficient + (1-coefficient)*this.lastOutput
          inpChannel2[i] = inpChannel[i-1]
          this.lastOutput=outputChannel[i]
        }
  //Use the console to debug, remember when accessing a value, be sure it exists first
      }
      return true
    }
  })
  
  